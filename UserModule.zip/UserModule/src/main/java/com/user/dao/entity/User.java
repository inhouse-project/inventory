package com.user.dao.entity;

public class User {

}
